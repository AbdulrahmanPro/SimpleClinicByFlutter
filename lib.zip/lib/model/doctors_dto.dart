class DoctorsDTO {
  final int id;
  final int personId;
  final String? specialization;

  const DoctorsDTO({
    required this.id,
    required this.personId,
    this.specialization,
  });

  factory DoctorsDTO.fromJson(Map<String, dynamic> json) {
    return DoctorsDTO(
      id: json['id'],
      personId: json['personId'],
      specialization: json['specialization'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'personId': personId,
      'specialization': specialization,
    };
  }
}
