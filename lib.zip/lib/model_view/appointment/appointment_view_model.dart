import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:test_provider_mvvm/data/repositories/appointment_repository.dart';
import 'package:test_provider_mvvm/model/apointment_dto.dart';

class AppointmentViewModel extends StateNotifier<AsyncValue<List<AppointmentDTO>>> {
  final AppointmentRepository repository;

  AppointmentViewModel(this.repository) : super(const AsyncValue.loading()) {
    fetchAppointments();
  }

  Future<void> fetchAppointments() async {
    try {
      state = const AsyncValue.loading();
      final appointments = await repository.fetchAppointments();
      state = AsyncValue.data(appointments);
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  Future<void> createAppointment(AppointmentDTO appointment) async {
    try {
      state = const AsyncValue.loading();
      final newAppointment = await repository.createAppointment(appointment);
      state = AsyncValue.data([newAppointment]); // Update the state with the new appointment
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  Future<void> updateAppointment(int id, AppointmentDTO appointment) async {
    try {
      await repository.updateAppointment(id, appointment);
      fetchAppointments(); // Refresh the appointments list after update
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  Future<void> deleteAppointment(int id) async {
    try {
      await repository.deleteAppointment(id);
      fetchAppointments(); // Refresh the appointments list after delete
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }
}
