import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:test_provider_mvvm/data/repositories/doctors_repository.dart';
import 'package:test_provider_mvvm/model/doctors_dto.dart';

class DoctorsViewModel extends StateNotifier<AsyncValue<List<DoctorsDTO>>> {
  final DoctorsRepository repository;

  DoctorsViewModel(this.repository) : super(const AsyncValue.loading()) {
    fetchDoctors();
  }

  Future<void> fetchDoctors() async {
    try {
      state = const AsyncValue.loading();
      final doctors = await repository.fetchDoctors();
      state = AsyncValue.data(doctors);
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  Future<void> createDoctor(DoctorsDTO doctor) async {
    try {
      state = const AsyncValue.loading();
      final newDoctor = await repository.createDoctor(doctor);
      state = AsyncValue.data([newDoctor]); // Update the state with the new doctor
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  Future<void> updateDoctor(int id, DoctorsDTO doctor) async {
    try {
      await repository.updateDoctor(id, doctor);
      fetchDoctors(); // Refresh the doctors list after update
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  Future<void> deleteDoctor(int id) async {
    try {
      await repository.deleteDoctor(id);
      fetchDoctors(); // Refresh the doctors list after delete
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }
}
