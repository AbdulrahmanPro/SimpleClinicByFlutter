import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:test_provider_mvvm/data/repositories/patients_repository.dart';
import 'package:test_provider_mvvm/model/patient_all_info_dto.dart';

class PatientsViewModel
    extends StateNotifier<AsyncValue<List<PatientAllInfoDTO>>> {
  final PatientsRepository repository;

  PatientsViewModel(this.repository) : super(const AsyncValue.loading()) {
    fetchPatients();
  }

  Future<void> fetchPatients() async {
    try {
      state = const AsyncValue.loading();
      final patients = await repository.fetchPatientsAllInfo();
      state = AsyncValue.data(patients);
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  Future<void> createPatient(PatientAllInfoDTO patient) async {
    try {
      await repository.createPatient(patient);
      fetchPatients(); // Refresh after adding a new patient
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  Future<void> updatePatient(int id, PatientAllInfoDTO patient) async {
    try {
      await repository.updatePatient(id, patient);
      fetchPatients(); // Refresh after updating
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  Future<void> deletePatient(int id) async {
    try {
      await repository.deletePatient(id);
      fetchPatients(); // Refresh after deleting
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }
}
