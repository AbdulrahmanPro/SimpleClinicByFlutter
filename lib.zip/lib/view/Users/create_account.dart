// register_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:your_project/providers/register_provider.dart';
import 'package:your_project/widgets/custom_text_field.dart';

class RegisterScreen extends ConsumerWidget {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _dobController = TextEditingController();
  final _genderController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();
  final _userNameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _specializationController = TextEditingController();

  String? _selectedAdditionalRole;

  RegisterScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final registerState = ref.watch(registerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Register Screen'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              CustomTextField(
                controller: _nameController,
                label: 'Full Name',
                icon: Icons.person,
                validator: (value) {
                  if (value?.isEmpty == true) {
                    return 'Please enter your full name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              CustomTextField(
                controller: _dobController,
                label: 'Date of Birth',
                icon: Icons.calendar_today,
                validator: (value) {
                  if (value?.isEmpty == true) {
                    return 'Please enter your date of birth';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              CustomTextField(
                controller: _genderController,
                label: 'Gender',
                icon: Icons.person,
                validator: (value) {
                  if (value?.isEmpty == true) {
                    return 'Please enter your gender';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              CustomTextField(
                controller: _phoneController,
                label: 'Phone Number',
                icon: Icons.phone,
                validator: (value) {
                  if (value?.isEmpty == true) {
                    return 'Please enter your phone number';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              CustomTextField(
                controller: _emailController,
                label: 'Email',
                icon: Icons.email,
                validator: (value) {
                  if (value?.isEmpty == true) {
                    return 'Please enter your email';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              CustomTextField(
                controller: _addressController,
                label: 'Address',
                icon: Icons.home,
                validator: (value) {
                  if (value?.isEmpty == true) {
                    return 'Please enter your address';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              
              // User registration fields (required for all)
              CustomTextField(
                controller: _userNameController,
                label: 'Username',
                icon: Icons.person,
                validator: (value) {
                  if (value?.isEmpty == true) {
                    return 'Please enter your username';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              CustomTextField(
                controller: _passwordController,
                label: 'Password',
                icon: Icons.lock,
                isPassword: true,
                validator: (value) {
                  if (value?.isEmpty == true) {
                    return 'Please enter your password';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              
              // Role selection
              DropdownButtonFormField<String>(
                value: _selectedAdditionalRole,
                hint: const Text('Select Additional Role (Doctor, Patient)'),
                items: const [
                  DropdownMenuItem(value: 'doctor', child: Text('Doctor')),
                  DropdownMenuItem(value: 'patient', child: Text('Patient')),
                ],
                onChanged: (value) {
                  _selectedAdditionalRole = value;
                },
              ),
              const SizedBox(height: 20),

              // Show specialization input only if the role is Doctor
              if (_selectedAdditionalRole == 'doctor')
                CustomTextField(
                  controller: _specializationController,
                  label: 'Specialization',
                  icon: Icons.medical_services,
                  validator: (value) {
                    if (value?.isEmpty == true) {
                      return 'Please enter your specialization';
                    }
                    return null;
                  },
                ),

              const SizedBox(height: 20),

              if (registerState.isLoading) 
                const CircularProgressIndicator(),
              if (registerState.hasError)
                Text('Error: ${registerState.error}', style: TextStyle(color: Colors.red)),

              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState?.validate() == true) {
                    await ref.read(registerProvider.notifier).registerPerson(
                      _nameController.text.trim(),
                      _dobController.text.trim(),
                      _genderController.text.trim(),
                      _phoneController.text.trim(),
                      _emailController.text.trim(),
                      _addressController.text.trim(),
                      _selectedAdditionalRole ?? '',
                      _userNameController.text.trim(),
                      _passwordController.text.trim(),
                      _specializationController.text.trim(),
                    );
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Registration successful')),
                    );
                  }
                },
                child: const Text('Register'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
