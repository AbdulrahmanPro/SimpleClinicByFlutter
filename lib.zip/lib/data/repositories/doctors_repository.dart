import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:test_provider_mvvm/model/doctors_dto.dart';
import 'package:test_provider_mvvm/data/repositories/baseurl/baseural.dart';

class DoctorsRepository {
  Future<List<DoctorsDTO>> fetchDoctors() async {
    try {
      final response = await http.get(Uri.parse('${Baseural.baseUrl}/doctors'));
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        return data.map((json) => DoctorsDTO.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load doctors');
      }
    } catch (e) {
      throw Exception('Error fetching doctors: $e');
    }
  }

  Future<DoctorsDTO> createDoctor(DoctorsDTO doctor) async {
    try {
      final response = await http.post(
        Uri.parse('${Baseural.baseUrl}/doctors'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(doctor.toJson()),
      );
      if (response.statusCode == 201) {
        return DoctorsDTO.fromJson(json.decode(response.body));
      } else {
        throw Exception('Failed to create doctor');
      }
    } catch (e) {
      throw Exception('Error creating doctor: $e');
    }
  }

  Future<void> updateDoctor(int id, DoctorsDTO doctor) async {
    try {
      final response = await http.put(
        Uri.parse('${Baseural.baseUrl}/doctors/$id'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(doctor.toJson()),
      );
      if (response.statusCode != 200) {
        throw Exception('Failed to update doctor');
      }
    } catch (e) {
      throw Exception('Error updating doctor: $e');
    }
  }

  Future<void> deleteDoctor(int id) async {
    try {
      final response = await http.delete(Uri.parse('${Baseural.baseUrl}/doctors/$id'));
      if (response.statusCode != 200) {
        throw Exception('Failed to delete doctor');
      }
    } catch (e) {
      throw Exception('Error deleting doctor: $e');
    }
  }
}
