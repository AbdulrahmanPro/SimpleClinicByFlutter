import 'dart:convert';
import 'package:test_provider_mvvm/model/usermodel.dart';
import 'baseurl/baseural.dart';
import 'package:http/http.dart' as http;

class UserRepositry {
  Future<List<UserModel>> fetchUsers() async {
    try {
      final response =
          await http.get(Uri.parse('${Baseural.baseUrl}/UserApi/All'));
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        return data.map((json) => UserModel.fromJson(json)).toList();
      } else {
        throw Exception('Failed to fetch persons: ${response.body}');
      }
    } catch (e) {
      print('Error in fetchUsers: $e');
      throw Exception('Error in fetchUsers: $e');
    }
  }

  Future<UserModel> getUserByID(int id) async {
    try {
      final response =
          await http.get(Uri.parse('${Baseural.baseUrl}/UserApi/Find/$id)'));
      if (response.statusCode == 200) {
        return UserModel.fromJson(json.decode(response.body));
      } else {
        throw Exception('Failed to get user by ID: ${response.body}');
      }
    } catch (e) {
      print('Error in getUserByID: $e');
      throw Exception('Error in getUserByID: $e');
    }
  }

  Future<void> createUser(UserModel newUser) async {
    try {
      final response = await http.post(
        Uri.parse('${Baseural.baseUrl}/UserApi/Add'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(newUser.toJson()),
      );

      if (response.statusCode != 201) {
        throw Exception('Failed to create user: ${response.body}');
      }
    } catch (e) {
      print('Error in createUser: $e');
      throw Exception('Error in createUser: $e');
    }
  }

  Future<bool> fetchPersonByUserNameAndPassword(
      String userName, String password) async {
    try {
      final response = await http.get(Uri.parse(
          '${Baseural.baseUrl}/UserApi/CheckCredentials/UserName/$userName/Password/$password'));

      if (response.statusCode == 200) {
        bool isValid = true;
        return isValid;
      } else {
        print('Error in fetchPersonByUserNameAndPassword: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Connection error in fetchPersonByUserNameAndPassword: $e');
      return false;
    }
  }

  Future<void> updateUser(int id, UserModel user) async {
    try {
      final response = await http.put(
        Uri.parse('${Baseural.baseUrl}/UserApi/Update/$id'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(user.toJson()),
      );

      if (response.statusCode != 200) {
        throw Exception('Failed to update user: ${response.body}');
      }
    } catch (e) {
      print('Error in updateUser: $e');
      throw Exception('Error in updateUser: $e');
    }
  }

  Future<void> deleteUser(int id) async {
    try {
      final response = await http
          .delete(Uri.parse('${Baseural.baseUrl}/UserApi/Delete/$id'));

      if (response.statusCode != 200) {
        throw Exception('Failed to delete user: ${response.body}');
      }
    } catch (e) {
      print('Error in deleteUser: $e');
      throw Exception('Error in deleteUser: $e');
    }
  }
}
