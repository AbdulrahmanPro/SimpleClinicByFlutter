import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:test_provider_mvvm/model/patient_all_info_dto.dart';
import 'package:test_provider_mvvm/model/patients_dto.dart';
import 'package:test_provider_mvvm/data/repositories/baseurl/baseural.dart';

class PatientsRepository {
  Future<List<PatientAllInfoDTO>> fetchPatientsAllInfo() async {
    try {
      final response =
          await http.get(Uri.parse('${Baseural.baseUrl}/patientsAllInfo'));
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        return data.map((json) => PatientAllInfoDTO.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load patients info');
      }
    } catch (e) {
      throw Exception('Error fetching patients info: $e');
    }
  }

  Future<List<PatientsDTO>> fetchPatients() async {
    try {
      final response =
          await http.get(Uri.parse('${Baseural.baseUrl}/patients'));
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        return data.map((json) => PatientsDTO.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load patients');
      }
    } catch (e) {
      throw Exception('Error fetching patients: $e');
    }
  }

  Future<void> createPatient(PatientAllInfoDTO patient) async {
    try {
      final response = await http.post(
        Uri.parse('${Baseural.baseUrl}/patientsAllInfo'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(patient.toJson()),
      );
      if (response.statusCode != 201) {
        throw Exception('Failed to create patient');
      }
    } catch (e) {
      throw Exception('Error creating patient: $e');
    }
  }

  Future<void> updatePatient(int id, PatientAllInfoDTO patient) async {
    try {
      final response = await http.put(
        Uri.parse('${Baseural.baseUrl}/patientsAllInfo/$id'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(patient.toJson()),
      );
      if (response.statusCode != 200) {
        throw Exception('Failed to update patient');
      }
    } catch (e) {
      throw Exception('Error updating patient: $e');
    }
  }

  Future<void> deletePatient(int id) async {
    try {
      final response = await http.delete(
        Uri.parse('${Baseural.baseUrl}/patientsAllInfo/$id'),
      );
      if (response.statusCode != 200) {
        throw Exception('Failed to delete patient');
      }
    } catch (e) {
      throw Exception('Error deleting patient: $e');
    }
  }
}
