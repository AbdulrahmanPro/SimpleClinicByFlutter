import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:test_provider_mvvm/data/repositories/patients_repository.dart';
import 'package:test_provider_mvvm/model/patient_all_info_dto.dart';
import 'package:test_provider_mvvm/model_view/patients/patients_view_model.dart';

final patientsRepositoryProvider = Provider((ref) => PatientsRepository());

final patientsViewModelProvider = StateNotifierProvider<PatientsViewModel,
    AsyncValue<List<PatientAllInfoDTO>>>(
  (ref) => PatientsViewModel(ref.read(patientsRepositoryProvider)),
);
