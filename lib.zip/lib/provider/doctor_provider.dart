import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:test_provider_mvvm/data/repositories/doctors_repository.dart';
import 'package:test_provider_mvvm/model/doctors_dto.dart';
import 'package:test_provider_mvvm/model_view/doctors/doctors_view_model.dart';

final doctorsRepositoryProvider = Provider((ref) => DoctorsRepository());

final doctorsViewModelProvider =
    StateNotifierProvider<DoctorsViewModel, AsyncValue<List<DoctorsDTO>>>(
  (ref) => DoctorsViewModel(ref.read(doctorsRepositoryProvider)),
);
